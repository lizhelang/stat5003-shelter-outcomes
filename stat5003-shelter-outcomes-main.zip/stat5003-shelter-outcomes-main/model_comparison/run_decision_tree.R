# Decision tree: shared five-fold CV, selected configuration, and holdout.
# Run from the repository root:
# Rscript model_comparison/run_decision_tree.R

suppressPackageStartupMessages({
  library(rpart)
})

# Load the shared preprocessing into an isolated environment.
shared <- new.env(parent = globalenv())
invisible(capture.output(
  sys.source("report_support/preprocessing.R", envir = shared)
))

output_dir <- "model_comparison/review_results"
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

write_result <- function(x, name) {
  write.csv(
    x, file.path(output_dir, name),
    row.names = FALSE, na = ""
  )
}

classes <- levels(shared$y_train)
stopifnot(
  identical(classes,
            c("Adoption", "Transfer", "Return", "Euthanasia", "Other")),
  length(shared$cv_data) == 5L,
  nrow(shared$x_train) == length(shared$y_train),
  nrow(shared$x_test) == length(shared$y_test)
)

# Consistent metric definitions across all models.
class_metrics <- function(actual, predicted) {
  actual <- factor(actual, levels = classes)
  predicted <- factor(predicted, levels = classes)

  stopifnot(
    length(actual) == length(predicted),
    !anyNA(actual),
    !anyNA(predicted)
  )

  cm <- table(actual, predicted)
  tp <- diag(cm)
  support <- rowSums(cm)
  n_predicted <- colSums(cm)

  data.frame(
    Class = classes,
    Support = as.integer(support),
    Precision = ifelse(n_predicted > 0, tp / n_predicted, 0),
    Recall = ifelse(support > 0, tp / support, 0),
    F1 = ifelse(
      support + n_predicted > 0,
      2 * tp / (support + n_predicted),
      0
    ),
    row.names = NULL
  )
}

metrics <- function(actual, predicted) {
  pc <- class_metrics(actual, predicted)

  c(
    Macro_F1 = mean(pc$F1),
    Balanced_Accuracy = mean(pc$Recall),
    Accuracy = mean(actual == predicted),
    Weighted_F1 = weighted.mean(pc$F1, pc$Support)
  )
}

# Train and predict one classification tree.
fit_tree <- function(x_train, y_train, x_valid,
                     cp, maxdepth, minsplit) {
  train_df <- as.data.frame(x_train)
  train_df$Outcome.Group <- factor(y_train, levels = classes)

  model <- rpart::rpart(
    Outcome.Group ~ .,
    data = train_df,
    method = "class",
    control = rpart::rpart.control(
      cp = cp,
      maxdepth = maxdepth,
      minsplit = minsplit,
      xval = 0
    ),
    model = TRUE
  )

  valid_df <- as.data.frame(x_valid)

  # Preserve the outcome class order, including classes not predicted.
  predicted <- predict(model, newdata = valid_df, type = "class")
  predicted <- factor(as.character(predicted), levels = classes)

  list(model = model, predicted = predicted)
}

# A small, explicit complexity grid.
# Larger cp values penalise additional splits; maxdepth limits tree depth.
tree_grid <- expand.grid(
  cp = c(0.001, 0.005, 0.01, 0.02),
  maxdepth = c(3L, 5L, 8L),
  minsplit = c(20L, 50L),
  KEEP.OUT.ATTRS = FALSE,
  stringsAsFactors = FALSE
)

# Score every candidate on the same five training-only CV folds.
grid_fold_rows <- list()
candidate_predictions <- vector("list", nrow(tree_grid))

for (i in seq_len(nrow(tree_grid))) {
  cfg <- tree_grid[i, ]
  candidate_predictions[[i]] <- vector("list", 5L)

  for (k in seq_len(5L)) {
    fold <- shared$cv_data[[k]]

    fitted <- fit_tree(
      x_train = fold$x_train,
      y_train = fold$y_train,
      x_valid = fold$x_valid,
      cp = cfg$cp,
      maxdepth = cfg$maxdepth,
      minsplit = cfg$minsplit
    )

    candidate_predictions[[i]][[k]] <- fitted$predicted
    fold_metrics <- metrics(fold$y_valid, fitted$predicted)

    grid_fold_rows[[length(grid_fold_rows) + 1L]] <- data.frame(
      Grid_ID = i,
      Fold = k,
      cp = cfg$cp,
      maxdepth = cfg$maxdepth,
      minsplit = cfg$minsplit,
      Macro_F1 = unname(fold_metrics["Macro_F1"]),
      Balanced_Accuracy = unname(fold_metrics["Balanced_Accuracy"]),
      Accuracy = unname(fold_metrics["Accuracy"]),
      Weighted_F1 = unname(fold_metrics["Weighted_F1"])
    )
  }
}

grid_fold_scores <- do.call(rbind, grid_fold_rows)

grid_summary <- do.call(
  rbind,
  lapply(split(grid_fold_scores, grid_fold_scores$Grid_ID), function(z) {
    data.frame(
      Grid_ID = z$Grid_ID[1],
      cp = z$cp[1],
      maxdepth = z$maxdepth[1],
      minsplit = z$minsplit[1],
      Mean_CV_Macro_F1 = mean(z$Macro_F1),
      SD_CV_Macro_F1 = sd(z$Macro_F1),
      Mean_CV_Balanced_Accuracy = mean(z$Balanced_Accuracy),
      Mean_CV_Accuracy = mean(z$Accuracy),
      Mean_CV_Weighted_F1 = mean(z$Weighted_F1)
    )
  })
)

# Deterministic tie-breaking: prefer higher macro-F1, then higher
# balanced accuracy, then shallower trees, then larger cp.
grid_summary <- grid_summary[
  order(
    -grid_summary$Mean_CV_Macro_F1,
    -grid_summary$Mean_CV_Balanced_Accuracy,
    grid_summary$maxdepth,
    -grid_summary$cp,
    grid_summary$minsplit
  ),
]

selected <- grid_summary[1, ]
selected_grid_id <- selected$Grid_ID

write_result(grid_fold_scores, "decision_tree_grid_fold_scores.csv")
write_result(grid_summary, "decision_tree_grid_summary.csv")
write_result(selected, "decision_tree_selected_config.csv")

# Save one out-of-fold prediction for each training row, using the
# selected configuration and the original shared fold assignments.
oof_predictions <- rep(NA_character_, length(shared$y_train))
fold_id <- integer(length(shared$y_train))

for (k in seq_len(5L)) {
  rows <- shared$cv_folds[[k]]
  fold <- shared$cv_data[[k]]
  pred <- candidate_predictions[[selected_grid_id]][[k]]

  stopifnot(length(rows) == length(pred))

  oof_predictions[rows] <- as.character(pred)
  fold_id[rows] <- k
}

stopifnot(!anyNA(oof_predictions), all(fold_id %in% 1:5))

oof <- data.frame(
  Training_Row = seq_along(shared$y_train),
  Actual = as.character(shared$y_train),
  Predicted = oof_predictions,
  Fold = fold_id
)

write_result(oof, "decision_tree_selected_oof_predictions.csv")

# Pooled out-of-fold performance.
oof_metrics <- metrics(oof$Actual, oof$Predicted)
oof_pc <- class_metrics(oof$Actual, oof$Predicted)

write_result(
  data.frame(
    Metric = names(oof_metrics),
    Value = as.numeric(oof_metrics)
  ),
  "decision_tree_oof_metrics.csv"
)
write_result(oof_pc, "decision_tree_oof_per_class.csv")

# Per-fold metrics for the selected configuration.
selected_fold_scores <- do.call(
  rbind,
  lapply(seq_len(5L), function(k) {
    rows <- oof$Fold == k
    m <- metrics(oof$Actual[rows], oof$Predicted[rows])

    data.frame(
      Fold = k,
      cp = selected$cp,
      maxdepth = selected$maxdepth,
      minsplit = selected$minsplit,
      Macro_F1 = unname(m["Macro_F1"]),
      Balanced_Accuracy = unname(m["Balanced_Accuracy"]),
      Accuracy = unname(m["Accuracy"]),
      Weighted_F1 = unname(m["Weighted_F1"])
    )
  })
)

write_result(
  selected_fold_scores,
  "decision_tree_selected_oof_fold_scores.csv"
)

selected_cv_summary <- data.frame(
  Model = "Decision tree",
  Mean_CV_Macro_F1 = mean(selected_fold_scores$Macro_F1),
  SD_CV_Macro_F1 = sd(selected_fold_scores$Macro_F1),
  Mean_CV_Balanced_Accuracy =
    mean(selected_fold_scores$Balanced_Accuracy),
  Mean_CV_Accuracy = mean(selected_fold_scores$Accuracy),
  Mean_CV_Weighted_F1 = mean(selected_fold_scores$Weighted_F1),
  cp = selected$cp,
  maxdepth = selected$maxdepth,
  minsplit = selected$minsplit
)

write_result(selected_cv_summary, "decision_tree_selected_metrics.csv")

# Final model: fit on the complete training partition, then score holdout.
final_fit <- fit_tree(
  x_train = shared$x_train,
  y_train = shared$y_train,
  x_valid = shared$x_test,
  cp = selected$cp,
  maxdepth = selected$maxdepth,
  minsplit = selected$minsplit
)

holdout <- data.frame(
  Test_Row = seq_along(shared$y_test),
  Actual = as.character(shared$y_test),
  Predicted = as.character(final_fit$predicted)
)

write_result(holdout, "decision_tree_holdout_predictions.csv")

holdout_metrics <- metrics(holdout$Actual, holdout$Predicted)
holdout_pc <- class_metrics(holdout$Actual, holdout$Predicted)

write_result(
  data.frame(
    Metric = names(holdout_metrics),
    Value = as.numeric(holdout_metrics)
  ),
  "decision_tree_holdout_metrics.csv"
)
write_result(holdout_pc, "decision_tree_holdout_per_class.csv")

# Feature importance from the final training-only fit.
importance <- final_fit$model$variable.importance

if (is.null(importance) || length(importance) == 0L) {
  importance_df <- data.frame(
    Feature = character(),
    Importance = numeric()
  )
} else {
  importance_df <- data.frame(
    Feature = names(importance),
    Importance = as.numeric(importance),
    row.names = NULL
  )
  importance_df <- importance_df[
    order(-importance_df$Importance, importance_df$Feature),
  ]
}

write_result(importance_df, "decision_tree_feature_importance.csv")

message("Decision-tree grid search, OOF evaluation, and holdout evaluation completed.")
message("Selected configuration: cp=", selected$cp,
        ", maxdepth=", selected$maxdepth,
        ", minsplit=", selected$minsplit)
message("Mean CV macro-F1: ",
        round(selected_cv_summary$Mean_CV_Macro_F1, 4))
message("Holdout macro-F1: ",
        round(unname(holdout_metrics["Macro_F1"]), 4))
